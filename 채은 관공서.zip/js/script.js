jQuery(document).ready(function(){
// 상단 전체메뉴 보기
	$('.allbtn').click(function(){
		$('#allmenu').slideDown(500);
	});
	$('.allmenu_close').click(function(){
		$('#allmenu').slideUp(500);
	});
	
// 나의 도서관 메뉴 클릭시 alert 띄우기
	// index
	$('.alert').click(function(e){
		e.preventDefault();
		alert('도서관 정회원으로 로그인후 사용하세요.');
		window.location = 'sub/sub_4.html';
	});
	// sub
	$('.sub_alert').click(function(e){
		e.preventDefault();
		alert('도서관 정회원으로 로그인후 사용하세요.');
		window.location = 'sub_4.html';
	});
	
	
// info		
	$('.search_b_w .guide').each(function(){
		var guideText=this.defaultValue;
		//var guideText=$(this).value();
		var element=$(this);
		if(element.val()===guideText){
			element.addClass('g_txt');
		}
		element.focus(function(){
			if(element.val()===guideText){
				element.val('');
				element.removeClass('g_txt');
			}
		});
		element.blur(function(){
			if(element.val()===''){
				element.val(guideText);
				element.addClass('g_txt');
			}
		});
	});

//main tit_banner
     $('.tit_slide').each(function(){
		var container=$(this);
		var timer1;
		var timer2;
		var tit_text1=$('.tit_text1');
		var tit_text2=$('.tit_text2');
		var tit_text3=$('.tit_text3');
		tit_text1.animate({top:"5px", opacity:1},1000);
		tit_text2.animate({top:"150px", opacity:1},1000);
		tit_text3.animate({top:"250px", opacity:1},1000);
		
		function switchImg(){
			var anchors=container.find('li');
			var first=anchors.eq(0);
			var second=anchors.eq(1);
			first.fadeOut(2000).appendTo(container);
			second.fadeIn(2000);			
		}
		function textslider(){
			tit_text1.css({'top':'-100px','opacity':'0'}).animate({top:"5px", opacity:1},1500);
			tit_text2.css({'top':'0px','opacity':'0'}).animate({top:"150px", opacity:1},1500);
			tit_text3.css({'top':'0px','opacity':'0'}).animate({top:"250px", opacity:1},1500);
		};
		function startTimer(){
			timer1=setInterval(switchImg,5000);
			timer2=setInterval(textslider,5000);
		}
		function stopTimer(){
			clearInterval(timer1);
			clearInterval(timer2);
		}
		container.hover(function(){
			stopTimer();
		},function(){
			startTimer();
		});
		startTimer();
	});  
	
// 도서관 일정
 	var monSlide=$('.mon_slide ul');
	var mCurrent=0;
	//var setIntervalId;
	var mSlideWidth=monSlide.width();
	var mSlideListWidth=monSlide.find('li').width();

	// 양쪽 버튼 제어
	$('.month_w .prev').click(function(e){
		e.preventDefault(); // a태그의 링크기능 차단
		monSlide.find('li:last').insertBefore('.mon_slide li:first'); //맨 뒤의 이미지를 맨 앞으로 붙이기
		monSlide.css({left:-mSlideListWidth});
		monSlide.stop().animate({left:0},0);
	});
	$('.month_w .next').click(function(e){
		e.preventDefault(); // a태그의 링크기능 차단
		monSlide.stop().animate({left:-mSlideListWidth},0,function(){
			monSlide.find('li:first').insertAfter('.mon_slide li:last');
			monSlide.css({left: 0});
		});
	}); 


//event_area slide
	var eSlide=$('.event_w ul');
	var ePagination=$('.event_pagination ul li');
	var eCurrent=0;
	var eSetIntervalId;
	var eSetIntervalBtn
	var eSlideWidth=eSlide.width();
	var eSlideListWidth=eSlide.find('li').width();

	// 슬라이드 움직임 기본 설정	
	eventSlide();
	function eventSlide(){
		eSetIntervalId=setInterval(function(){
			eSlide.stop().animate({left:-eSlideListWidth},500,function(){
				eSlide.find('li:first').insertAfter('.event_w li:last'); //맨 앞의 이미지를 맨 뒤로 붙이기
				eSlide.css({left: 0});
			});
		},4000);
	}
	// 불릿
	eBthslide();
	function eBthslide(){
		eSetIntervalBtn=setInterval(function(){
			var ePagination1=ePagination.eq(eCurrent);
			eCurrent++;
			ePagination1.removeClass('on');
			if(eCurrent==ePagination.size()){eCurrent=0}
			var ePagination2=ePagination.eq(eCurrent);
			ePagination2.addClass('on');
		},4000);
	}

	// 마우스 오버 시 슬라이드 멈춤	
	$('.event_area').hover(function(){
		clearInterval(eSetIntervalId);
		clearInterval(eSetIntervalBtn);
	},function(){
		eventSlide();
		eBthslide();
	}); 


	
//icon_banner 자주 이용하는 서비스
 	var iconSlide=$('.icon_slide_wrap ul');
	var current1=0;
	//var setIntervalId;
	var slideWidth1=iconSlide.width();
	var slideListWidth1=iconSlide.find('li').width();

	// 양쪽 버튼 제어
	$('.icon_b_prev').click(function(e){
		e.preventDefault(); // a태그의 링크기능 차단
		iconSlide.find('li:last').insertBefore('.icon_slide_wrap li:first'); //맨 뒤의 이미지를 맨 앞으로 붙이기
		iconSlide.css({left:-slideListWidth1});
		iconSlide.stop().animate({left:0},500);
	});
	$('.icon_b_next').click(function(e){
		e.preventDefault(); // a태그의 링크기능 차단
		iconSlide.stop().animate({left:-slideListWidth1},500,function(){
			iconSlide.find('li:first').insertAfter('.icon_slide_wrap li:last');
			iconSlide.css({left: 0});
		});
	}); 


//img_banner 팝업안내
	var slide=$('.img_banner_w ul');
	var pagination=$('#img_banner .img_b_pagination ul li');
	var current=0;
	var setIntervalId;
	var setIntervalBtn
	var slideWidth=slide.width();
	var slideListWidth=slide.find('li').width();

	// 슬라이드 움직임 기본 설정	
	imgSlide();
	function imgSlide(){
		setIntervalId=setInterval(function(){
			slide.stop().animate({left:-slideListWidth},500,function(){
				slide.find('li:first').insertAfter('.img_banner_w li:last'); //맨 앞의 이미지를 맨 뒤로 붙이기
				slide.css({left: 0});
			});
		},2000);
	}
	// 불릿
	bthslide();
	function bthslide(){
		setIntervalBtn=setInterval(function(){
			var pagination1=pagination.eq(current);
			current++;
			pagination1.removeClass('on');
			if(current==pagination.size()){current=0}
			var pagination2=pagination.eq(current);
			pagination2.addClass('on');
		},2000);
	}

	// 마우스 오버 시 슬라이드 멈춤	
	$('.img_banner_w').hover(function(){
		clearInterval(setIntervalId);
		clearInterval(setIntervalBtn);
	},function(){
		imgSlide();
		bthslide();
	}); 

	// 정지, 재생 버튼 제어
	var btn=true;
	var play=$('#img_banner .play');
	play.click(function(e){
		e.preventDefault();
		if(btn==true){
			clearInterval(setIntervalId);
			clearInterval(setIntervalBtn);
			$(this).find('img').attr('src','images/main/roll_play.png');
			btn=false;
		}else{
			imgSlide();
			$(this).find('img').attr('src','images/main/roll_stop.png');
			btn=true;
		}
	});
	
	
// 베스트자료
	var bestSlide=$('.best_con_list ul');
	var current3=0;
	//var setIntervalId;
	//var slideWidth3=bestSlide.width();
	var slideListWidth3=bestSlide.find('li').width();
	
	// 양쪽 버튼 제어
	$('.best_con .prev').click(function(e){
		e.preventDefault(); // a태그의 링크기능 차단
		bestSlide.find('li:last').insertBefore('.best_con_list li:first'); //맨 뒤의 이미지를 맨 앞으로 붙이기
		bestSlide.css({left:-slideListWidth3});
		bestSlide.stop().animate({left:0},500);
	});
	$('.best_con .next').click(function(e){
		e.preventDefault(); // a태그의 링크기능 차단
		bestSlide.stop().animate({left:-slideListWidth3},500,function(){
		bestSlide.find('li:first').insertAfter('.best_con_list li:last');
		bestSlide.css({left: 0});
		});
	}); 

	
	
// 이달의 추천도서
	//추천도서 슬라이드
	var reSlide=$('.re_slide_wrap ul');
	var current4=0;
	//var setIntervalId;
	var slideWidth4=reSlide.width();
	var slideListWidth4=reSlide.find('li').width();
	
	// 슬라이드 좌우 버튼 제어
	$('.book_date_w .prev').click(function(e){
		e.preventDefault(); // a태그의 링크기능 차단
		reSlide.find('li:last').insertBefore('.re_slide_wrap li:first'); //맨 뒤의 이미지를 맨 앞으로 붙이기
		reSlide.css({left:-slideListWidth4});
		reSlide.stop().animate({left:0},500);
	});
	$('.book_date_w .next').click(function(e){
		e.preventDefault(); // a태그의 링크기능 차단
		reSlide.stop().animate({left:-slideListWidth4},500,function(){
		reSlide.find('li:first').insertAfter('.re_slide_wrap li:last');
		reSlide.css({left: 0});
		});
	}); 
	
	// 신착도서 슬라이드
	var newSlide=$('.new_slide_wrap ul');
	var current5=0;
	//var setIntervalId;
	var slideWidth5=newSlide.width();
	var slideListWidth5=newSlide.find('li').width();
	
	// 슬라이드 좌우 버튼 제어
	$('.book_date_w .prev').click(function(e){
		e.preventDefault(); // a태그의 링크기능 차단
		newSlide.find('li:last').insertBefore('.new_slide_wrap li:first'); //맨 뒤의 이미지를 맨 앞으로 붙이기
		newSlide.css({left:-slideListWidth5});
		newSlide.stop().animate({left:0},500);
	});
	$('.book_date_w .next').click(function(e){
		e.preventDefault(); // a태그의 링크기능 차단
		newSlide.stop().animate({left:-slideListWidth5},500,function(){
		newSlide.find('li:first').insertAfter('.new_slide_wrap li:last');
		newSlide.css({left: 0});
		});
	}); 
	
	// 탭버튼
	$('.book_date_w').each(function(){
		var topDiv=$(this);
		var anchors=topDiv.find('.date_tab a');
		var panelDivs=topDiv.find('.date_list');
		var lastAnchor;
		var lastPanel;
		
		lastAnchor=anchors.filter('.on'); //.on 걸러내기
		lastPanel=$(lastAnchor.attr('href'));
		
		panelDivs.hide();
		lastPanel.show();
		
		anchors.click(function(e){
			e.preventDefault();
			var currentAnchor=$(this); //클릭하는 탭 설정
			var currentPanel=$(currentAnchor.attr('href'));
			lastAnchor.removeClass('on');
			currentAnchor.addClass('on');
			lastAnchor=currentAnchor;
			lastPanel.hide();
			currentPanel.show();
			lastPanel=currentPanel;
		});
	});
	
	
	
// 관련사이트	
	var slide6=$('.banner_wrap ul');
	var pagination3=$('.l_banner .img_b_pagination ul li');
	var current6=0;
	var setIntervalId6;
	var setIntervalBtn6;
	var slideWidth6=slide6.width();
	var slideListWidth6=slide6.find('li').width();

	// 슬라이드 움직임 기본 설정	
	siteSlide();
	function siteSlide(){
		setIntervalId6=setInterval(function(){
			slide6.stop().animate({left:-slideListWidth6},500,function(){
			slide6.find('li:first').insertAfter('.banner_wrap li:last'); //맨 앞의 이미지를 맨 뒤로 붙이기
			slide6.css({left: 0});
			});
		},2000);
	}
	// 불릿
	siteBthSlide();
	function siteBthSlide(){
		setIntervalBtn6=setInterval(function(){
			var pagination4=pagination3.eq(current6);
			current6++;
			pagination4.removeClass('on');
			if(current6==pagination3.size()){current6=0}
			var pagination5=pagination3.eq(current6);
			pagination5.addClass('on');
		},2000);
	}
	// 마우스 오버 시 슬라이드 멈춤	
	$('.banner_wrap').hover(function(){
		clearInterval(setIntervalId6);
		clearInterval(setIntervalBtn6);
	},function(){
		siteSlide();
		siteBthSlide();
	}); 

	// 정지, 재생 버튼 제어
	var btn6=true;
	var play6=$('#site .play');
	play6.click(function(e){
		e.preventDefault();
		if(btn6==true){
			clearInterval(setIntervalId6);
			clearInterval(setIntervalBtn6);
			$(this).find('img').attr('src','images/main/roll_play.png');
			btn6=false;
		}else{
			siteSlide();
			$(this).find('img').attr('src','images/main/roll_stop.png');
			btn6=true;
		}
	});


// sub	

	// sub_1 search_box input	
	$('.guideText').each(function(){
		var guideText=this.defaultValue;
		//var guideText=$(this).value();
		var element=$(this);
		if(element.val()===guideText){
			element.addClass('guide');
		}
		element.focus(function(){
			if(element.val()===guideText){
				element.val('');
				element.removeClass('guide');
			}
		});
		element.blur(function(){
			if(element.val()===''){
				element.val(guideText);
				element.addClass('guide');
			}
		});
	});
	
	//sub_1 탭
	$('.r_con_wrap').each(function(){
		var topDiv1=$(this);
		var anchors1=topDiv1.find('.search_tap a');
		var panelDivs1=topDiv1.find('.s_box');
		var lastAnchor1;
		var lastPanel1;
		
		lastAnchor1=anchors1.filter('.on'); //.on 걸러내기
		lastPanel1=$(lastAnchor1.attr('href'));
		
		panelDivs1.hide();
		lastPanel1.show();
		
		anchors1.click(function(e){
			e.preventDefault();
			var currentAnchor1=$(this); //클릭하는 탭 설정
			var currentPanel1=$(currentAnchor1.attr('href'));
			lastAnchor1.removeClass('on');
			currentAnchor1.addClass('on');
			lastAnchor1=currentAnchor1;
			lastPanel1.hide();
			currentPanel1.show();
			lastPanel1=currentPanel1;
		});
	});

	// sub_4 login input
	var idInput=$('.id .text_input');
	var idLabel=$('.id .label_style');
	var pwInput=$('.pw .text_input');
	var pwLabel=$('.pw .label_style');
	var deValue=this.defaultValue;
	idInput.focus(function(){
		idLabel.css('display','none');
	});
	idInput.blur(function(){
		if(idInput.val()===''){
			idLabel.css('display','block');
			idInput.val(deValue);
		}
	});	
	pwInput.focus(function(){
		pwInput.val('');
		pwLabel.css('display','none');
	});
	pwInput.blur(function(){
		if(pwInput.val()===''){			
			pwInput.val(deValue);
			pwLabel.css('display','block');
		}
	});
	
	
	
});