<?php
	$name=$_POST["name"];
	$id=$_POST["id"];
	$pass=$_POST["pass"];
	$phone1=$_POST["phone1"];
	$phone2=$_POST["phone2"];
	$phone3=$_POST["phone3"];
	$phone=$phone1."-".$phone2. "-" .$phone3.
	$regist_day=date("Y-m-d (H:i)");
	
	$con=mysqli_connect("localhost", "co97", "alcls!770", "co97");//mysql 서버 접속('host','사용자계정(root)','비밀번호','데이터베이스(sample)')
	
	$sql="insert into members (name, id, pass, phone, regist_day)";
	
	$sql .="values ('$id', '$pass', '$name', '$phone','$regist_day',9, 0 )";
	
	mysqli_query($con, $sql);//명령 실행
	
	mysqli_close($con);
	echo "<script>location.href='index.php'</script>";
	
?>