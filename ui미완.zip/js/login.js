function check_input(){
	if(!document.login-form.id.value){
		alert("아이디를 입력해 주세요");
		document.login-form.id.focus();
		return;
	}
	if(!document.login-form.pass.value){
		alert("비밀번호를 입력해 주세요");
		document.login-form.pass.focus();
		return;
	}
	document.login_form.submit();
}