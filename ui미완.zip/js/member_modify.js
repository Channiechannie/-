function check_input(){
    if(!document.join.userName.value){
        alert('닉네임을 입력해주세요');
        document.member_form.userName.focus();
        return;
    }
    if(!document.join.userId.value){
        alert('아이디를 입력해주세요');
        document.member_form.userId.focus();
        return;
    }
    if(!document.join.userPWD.value){
        alert('비밀번호를 입력해주세요');
        document.member_form.userPWD.focus();
        return;
    }
    if(!document.join.userPWDfoward.value){
        alert('비밀번호를 입력해주세요');
        document.member_form.userPWDfoward.focus();
        return;
    }
    }
    document.member_form.submit();
function check_id(){
    window.open("member_check_id.php?id=" + document.member_form.id.value, "IDcheck", "left=700, top=300, width=350, height=120, scrollbars=no, resizable=yes");
}
function reset_form(){
    document.member_form.name.value='';
    document.member_form.id.value='';
    document.member_form.pass.value='';
    document.member_form.phone.value='';
    document.member_form.id.focus();
}