<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/setting.css">
    <script src="https://kit.fontawesome.com/42fb4f473e.js" crossorigin="anonymous"></script>
</head>
<body>
    <form action="login-form.php" method="get" name="main">
        <div class="upside">
            <h2 class="logo"><img src="img/logo1.png" alt=""></h2>
            <div class="bar">
                <button type="button" class="btn1" onclick="location.href='list.php';"><i class="fas fa-bars"></i></button>
                <button type="button" class="btn2" onclick="location.href='bell.php';"><i class="fas fa-bell"></i></button>
            </div>
            <div class="swiper-container mySwiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <a href="#">
                            <img src="./img/event.png" alt="e1">
                        </a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#">
                            <img src="./img/1.png" alt="e2">
                        </a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#">
                            <img src="./img/event2.png" alt="e3">
                        </a>
                    </div>
                </div>
                <div class="swiper-pagination"></div>
            </div>
            <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
            <script>
            var swiper = new Swiper('.mySwiper', {
                    spaceBetween: 30,
                    direction: 'horizontal',
                    loop: true,
                    centeredSlides: true,
                    autoplay:{
                        delay: 2500,
                            disableOnInteraction: false,
                    },
                    // If we need pagination
                    pagination: {
                        el: '.swiper-pagination',
                        clickable: true,
                    },
                    });
            </script>
        </div> 
        <div class="bacode"></div>       
        <div class="downside">
            <div class="box1">
                <p class="box1title">즐겨찾기</p>
                <p class="box1menu">민트 크런치 프라페</p>
                <p class="box1menual">라지/초코칩추가/휘핑/테이크아웃</p>
                <p class="box1place"><i class="fas fa-map-marker-alt"></i>더벤티 강남점</p>
                <button type="button" class="btn1" onclick="location.href='order.php';">바로 주문</button>
            </div>
            <div class="box2">
                <button type="button" class="btn1" onclick="location.href='list.php';"><i class="fas fa-ticket-alt"></i></button>
                <button type="button" class="btn2" onclick="location.href='bell.php';"><i class="fas fa-stamp"></i></button>
                <button type="button" class="btn2" onclick="location.href='bell.php';"><i class="far fa-credit-card"></i></button>
            </div>
        </div>
    </form>
</body>
</html>