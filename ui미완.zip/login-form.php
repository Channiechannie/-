<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>로그인폼</title>
    <link rel="stylesheet" href="css/login-form.css">
    <link rel="stylesheet" href="css/setting.css">
</head>
<body>
    <form action="login-form.php" method="post" name="login-form" id="loginForm">
        <div class="login-form">
            <h2 class="logo">
                <span><p>맛을 디자인하다</p><br/>
                <img src="./img/logo.png" alt="logo" width="200px"></span>
            </h2>
            <fieldset>
                <ul>
                    <li><p>아이디</p><input type="text" name="id" placeholder="" /></li>
                    <li><p>비밀번호</p><input type="password" name="pass" placeholder="" id="pass" /></li>
                </ul>
                <div id="login_btn">
                    <a href="main.php" alt="login" onclick="check_input()">로그인</a>
                </div>
                <div id="forget_btn">
                    <a href="join.php" class="id" alt="idhelp" onclick="check_input()">회원가입</a>
                    <a href="join.php" class="pw"alt="pwhelp" onclick="check_input()">아이디 / 비밀번호 찾기</a>
                </div>
                <div class="buttons">
                      <img src="./img/kakaologo.png" alt="naver" width="20px" onclick="reset_form()"> 
                      <img src="./img/naverlogo.png" alt="kakao" width="20px" onclick="reset_form()"> 
                      <img src="./img/goglelogo.png" alt="google" width="20px"onclick="reset_form()"> 
                </div>
            </fieldset>
        </div>
    </form> 
</body>
</html>
 