create table members (
	num int not null auto_increment,
	id char(10) not null,
	pass char(10) not null,
	name char(10) not null,
	phone char(11) int,
	primary key(num)
);