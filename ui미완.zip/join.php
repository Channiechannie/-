<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>회원가입</title>
    <link rel="stylesheet" href="css/join.css">
    <link rel="stylesheet" href="css/setting.css">
    <link rel="stylesheet" href="members.sql">
</head>
<body>
    <form id="loginform" action="join.html" method="post" name="login">
        <fieldset>
            <h2 class="logo">
                <span><p>맛을 디자인하다</p><br/>
                <img src="img/logo.png" alt="logo" width="200px"></span> 
            </h2>
            <ul id="login">
                <li>
                    <label for="name" class="userStyle">닉네임</label>
                    <input type="text" id="userName" />
                 </li>
                <li>
                   <label for="id" class="idStyle">아이디</label>
                   <input type="text" id="userId" />
                </li>
                <li>
                   <label for="pass" class="pwStyle">비밀번호</label>
                   <input type="password" id="userPWD" />
                </li>
                <li>
                 <label for="phone" class="phoneStyle">휴대폰 번호</label>
                 <input type="text" id="userPWDfoward" />
              </li>
            </ul>
            <ul id="logincheck">
                <li>
                    <input type="checkbox" id="checkStyle">&nbsp;개인정보 수집 약관&nbsp;(필수)
                    <input type="checkbox" id="checkStyle">&nbsp;이메일 수신에 동의&nbsp;(선택)
                </li>
            </ul>
            <button class="join">회원가입</button>
        </fieldset>
    </form>    
</body>
</html>