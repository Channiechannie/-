<!doctype html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<title>데이터수집</title>
	<link rel="stylesheet" href="./css/join.css"/>
	<link rel="stylesheet" href="./css/setting.css"/>
	<script src="./js/member_modify.js"></script>
</head>
<body>
	<header>
		<?php include "header.php"?>
	</header>
	<?php
		$con=mysqli_connect("localhost", 'co97',"alcls!770","co97");
	 
		
		$sql="select * from members where name='$username'";
	 
		$result=mysqli_query($con, $sql);
	 
		
		$row=mysqli_fetch_array($result);
	 
		$id=$row["id"]; 
		$pass=$row["pass"]; 
		
		$phone=explode("-", $row["phone"]); 
		$phone1=$phone[0]; 
		$phone2=$phone[1]; 
		
		mysqli_close($con);
	 
		
	?>
	<section>
    <h2 class="logo">
                <span><p>맛을 디자인하다</p><br/>
                <img src="img/logo.png" alt="logo" width="200px"></span> 
            </h2>
            <ul id="login">
                <li>
                    <label for="userName" class="userStyle">닉네임</label>
                    <input type="text" id="userName" />
                 </li>
                <li>
                   <label for="userId" class="idStyle">아이디</label>
                   <input type="text" id="userId" />
                </li>
                <li>
                   <label for="userPWD" class="pwStyle">비밀번호</label>
                   <input type="password" id="userPWD" />
                </li>
                <li>
                 <label for="userPhone" class="phoneStyle">휴대폰 번호</label>
                 <input type="password" id="userPWDfoward" />
              </li>
            </ul>
            <ul id="logincheck">
                <li>
                    <input type="checkbox" id="checkStyle">&nbsp;개인정보 수집 약관&nbsp;(필수)
                    <input type="checkbox" id="checkStyle">&nbsp;이메일 수신에 동의&nbsp;(선택)
                </li>
            </ul>
            <a href="main.php"><button class="join">회원가입</button></a>
	</section>
	<footer>
		<?php include "footer.php"?>
	</footer>
</body>
</html>