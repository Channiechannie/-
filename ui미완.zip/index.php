<!doctype html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/setting.css"/>
    <link rel="stylesheet" href="css/login-form.css">
</head>
<body>
	<header>
		<?php include "login-form.php"?> 
		
	</header>
</body>
</html>