from flask import Flask, render_template
app = Flask(__name__)

from pymongo import MongoClient
client = MongoClient('localhost', 27017)
db = client.dbsimple

@app.route('/')
def home():
   return render_template ('index.html')

@app.route('/register.html')
def register():
    return render_template('register.html')

@app.route('/index.html')
def index():
    return render_template('index.html')


if __name__ == '__main__':
   app.run('0.0.0.0',port=3000,debug=True)




