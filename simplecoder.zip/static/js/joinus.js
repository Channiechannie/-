$(document).ready(function () {
    joinUs();
});

function joinUs() {
    let name = $('#name').val()
    let id = $('#id').val()
    let pw = $('#pw').val()

    $.ajax({
        type: "POST",
        url: "/joinus",
        data: {name_give:name,id_give:id,pw_give:pw},
        success: function (response) {
            alert(response["가입되셨습니다"]);
            window.location.reload('register.html');
        }
    })
}