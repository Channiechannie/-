from flask import Flask, render_template, jsonify, request
app = Flask(__name__)

from pymongo import MongoClient
client = MongoClient('localhost', 27017)
db = client.dbsimple

## HTML을 주는 부분
@app.route('/register.html')
def register():
    return render_template('register.html')

@app.route('/joinus', methods=['POST'])
def joinUs():
    name_receive = request.form['name_give']
    id_receive = request.form['id_give']
    pw_receive = request.form['pw_give']

    # DB에 삽입할 review 만들기
    doc = {
        'name': name_receive,
        'id': id_receive,
        'pw': pw_receive
    }
    db.simple.insert_one(doc)
    return jsonify({'회원가입되셨습니다!'})

